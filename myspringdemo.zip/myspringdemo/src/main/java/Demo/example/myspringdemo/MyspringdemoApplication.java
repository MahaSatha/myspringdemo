package Demo.example.myspringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyspringdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyspringdemoApplication.class, args);
	}

}
